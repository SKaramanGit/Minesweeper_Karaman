package com.example.minesweeper;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Popup;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MinesweeperGame extends Application {
    private static final int X_FIELDS = 16;
    private static final int Y_FIELDS = 16;

    private static Field[][] grid;

    /**
     * Checks if the game is won and returns a value if that is the case.
     * @return
     */
    public static boolean checkWin() {
        for (int x = 0; x < X_FIELDS; x++) {
            for (int y = 0; y < Y_FIELDS; y++) {
                Field currentField = grid[x][y];
                if (!currentField.visited && !currentField.bomb) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Creates the Gamecontent upon execution.
     * Sets bombs first in random order, adding it to the children of the root afterwards.
     * Countbombs is there to count the bombs around a field.
     * @return
     */
    public static Parent createContent () {
        Pane root = new Pane();

        root.setPrefSize(640, 640);

        grid = new Field[X_FIELDS][Y_FIELDS];

        for (int y = 0; y < Y_FIELDS; y++) {
            for (int x = 0; x < X_FIELDS; x++) {
                Field field = new Field(x,y, Math.random()<0.2);
                field.fieldNode.setFill(Color.LIGHTGRAY);
                grid[x][y] = field;
                root.getChildren().add(field);

            }
        }


        ArrayList<Field> bombList;// = new ArrayList();

        int countbombs = 0;
        for(int i = 0; i < X_FIELDS; i++) {
            for (int j = 0; j < Y_FIELDS; j++) {
                bombList = (ArrayList<Field>) getNeighbours(grid[i][j]);
                for(Field f : bombList) {
                    if (f.bomb) {
                        countbombs++;
                    }
                }

                if(!grid[i][j].bomb && countbombs > 0) {
                    grid[i][j].setBombCount(String.valueOf(countbombs));
                }
                countbombs = 0;
            }
        }


        return root;
    }

    /**
     * Gets the neighbors of a field by checking all corners.
     * @param field
     * @return
     */
    static List<Field> getNeighbours(Field field) {

        List<Field> neighbours = new ArrayList<>();

        int[] points = new int[] {
                -1, -1,
                -1, 0,
                -1, 1,
                0, -1,
                0, 1,
                1, -1,
                1, 0,
                1, 1
        };

        for (int i = 0; i < points.length; i++) {
            int dx = points[i]; // delta X
            int dy = points[i+1]; // delta Y

            int newX = field.getX() + dx; // get the field on the specific Position
            int newY = field.getY() + dy;

            // add neighbor only if in bounds
            if (newX >= 0 && newX < X_FIELDS && newY >= 0&& newY < Y_FIELDS) {
                neighbours.add(grid[newX][newY]);
            }
            i++;
        }

        return neighbours;
    }

    /**
     * Main Stage/Scenes.
     * @param stage
     * @throws IOException
     */
    @Override
    public void start(Stage stage) throws IOException {
        //FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(createContent());
        stage.setTitle("Minesweeper");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
        stage.getIcons().add(new Image("C:\\Users\\samed\\Downloads\\mine\\Minesweeper\\src\\main\\resources\\com\\example\\minesweeper\\taskicon.png"));
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }


}