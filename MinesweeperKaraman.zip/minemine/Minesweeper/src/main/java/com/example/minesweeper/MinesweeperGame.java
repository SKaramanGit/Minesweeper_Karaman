package com.example.minesweeper;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.example.minesweeper.Field.FIELD_SIZE;

public class MinesweeperGame extends Application {

    private static int X_FIELDS;
    private static int Y_FIELDS;
    public AnchorPane anchorPane;
    public Label winLabel;
    private static MinesweeperGame instance;
    private static Pane pane;
    public ChoiceBox<String> difficultyChoiceBox;
    private static Field[][] grid;

    /*
    Initializes the first board.
     */
    public void initialize() {
        createContent(8, 8);
        winLabel.setText("Win/Loss");
        difficultySelector();
    }

    /**
     * Creates new boards after the first initial one.
     */
    public void newBoards() {
        createContent(8, 8);
        winLabel.setText("Win/Loss");
    }

    /**
     * To fix the NullPointerException problem.
     */
    public MinesweeperGame() {
        instance = this;
    }

    /**
     * CHecks if the game has been won by going through all the x and y fields.
     * @return
     */
    public static boolean checkWin() {
        boolean bombClicked = true;
        for (int x = 0; x < X_FIELDS; x++) {
            for (int y = 0; y < Y_FIELDS; y++) {
                Field currentField = grid[x][y];
                if (!currentField.visited && !currentField.bomb) {
                    bombClicked = false;
                    break;
                }
            }
        }
        return bombClicked;
    }

    /**
     * Sets the text to either "You Won!" or "You Lost!" in the label.
     * @param check
     */
    public static void setWinner(boolean check) {
        if (check) {
            MinesweeperGame.getInstance().winLabel.setText("You Won!");
        } else {
            MinesweeperGame.getInstance().winLabel.setText("You Lost!");
        }
    }

    /**
     * For solving the NullPointerException problem upon creation of the fields.
     * @return
     */
    public static MinesweeperGame getInstance() {
        if (instance == null) {
            instance = new MinesweeperGame();
        }
        return instance;
    }

    /**
     * Creates the Gamecontent upon execution.
     * Sets bombs first in random order, adding it to the children of the root afterwards.
     * Countbombs is there to count the bombs around a field.
     * @return
     */
    public void createContent (int xLength, int yLength) {
        X_FIELDS = xLength;
        Y_FIELDS = yLength;

        pane = new Pane();

        pane.setPrefSize(640, 640);

        anchorPane.getChildren().add(pane);

        grid = new Field[X_FIELDS][Y_FIELDS];

        for (int y = 0; y < Y_FIELDS; y++) {
            for (int x = 0; x < X_FIELDS; x++) {
                Field field = new Field(x,y, Math.random()<0.02);
                field.fieldNode.setFill(Color.LIGHTGRAY);
                grid[x][y] = field;
                pane.getChildren().add(field);

            }
        }

        ArrayList<Field> bombList;// = new ArrayList();

        int countbombs = 0;
        for(int i = 0; i < X_FIELDS; i++) {
            for (int j = 0; j < Y_FIELDS; j++) {
                bombList = (ArrayList<Field>) getNeighbours(grid[i][j]);
                for(Field f : bombList) {
                    if (f.bomb) {
                        countbombs++;
                    }
                }

                if(!grid[i][j].bomb && countbombs > 0) {
                    grid[i][j].setBombCount(String.valueOf(countbombs));
                }
                countbombs = 0;
            }
        }

    }

    /**
     * Initialises the difficulty levels.
     */
    public void difficultySelector() {
        difficultyChoiceBox.getItems().add("Beginner");
        difficultyChoiceBox.getItems().add("Advanced");
        difficultyChoiceBox.getItems().add("Pro");

        difficultyChoiceBox.setValue("Beginner");
    }

    /**
     * Changes the size of the board.
     */
    public void changeBoardSize() {
        pane.getChildren().clear();
        switch (difficultyChoiceBox.getValue()) {
            case "Beginner":
                FIELD_SIZE = 80;
                createContent(8, 8);
                break;
            case "Advanced":
                FIELD_SIZE = 40;
                createContent(16, 16);
                break;
            case "Pro":
                FIELD_SIZE = 20;
                createContent(32, 32);
                break;
        }
    }

    /**
     * Gets the neighbors of a field by checking all corners.
     * @param field
     * @return
     */
    static List<Field> getNeighbours(Field field) {

        List<Field> neighbours = new ArrayList<>();

        int[] points = new int[] {
                -1, -1,
                -1, 0,
                -1, 1,
                0, -1,
                0, 1,
                1, -1,
                1, 0,
                1, 1
        };

        for (int i = 0; i < points.length; i++) {
            int dx = points[i]; // delta X
            int dy = points[i+1]; // delta Y

            int newX = field.getX() + dx; // get the field on the specific Position
            int newY = field.getY() + dy;

            // add neighbor only if in bounds
            if (newX >= 0 && newX < X_FIELDS && newY >= 0&& newY < Y_FIELDS) {
                neighbours.add(grid[newX][newY]);
            }
            i++;
        }

        return neighbours;
    }

    /**
     * Main Stage/Scenes.
     * @param stage
     * @throws IOException
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MinesweeperGame.class.getResource("main.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 800);
        stage.setTitle("Minesweeper");
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
        stage.getIcons().add(new Image("file:src\\main\\resources\\com\\example\\minesweeper\\taskicon.png"));
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }


}