package com.example.minesweeper;

import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

import java.util.*;

public class Field extends StackPane {

    /** Variables, including:
     * visited to know if a field has been visited before,
     * oncebomb for the colors, as its marking a former bomb,
     * flagged to mark if a field is flagged.
     */
    public boolean visited;
    public boolean oncebomb;
    public boolean flagged;
    int x, y;
    public boolean bomb;
    private String text;

    public Text bombCount = new Text();
    public Rectangle fieldNode = null;
    public static int FIELD_SIZE;

    /** Main field constructor.
     *
     * @param x
     * @param y
     * @param bomb
     */
    public Field (int x, int y, boolean bomb) {
        this.x = x;
        visited = false;
        this.y = y;
        this.bomb = bomb;
        this.visited = false;
        this.flagged = false;
        this.oncebomb = false;
        setFieldStyles();

        bombCount.setText(this.bomb ? "X" : "");
        bombCount.setStroke(Color.DARKRED);
        bombCount.setVisible(false); // field default not opened


        getChildren().addAll(fieldNode, bombCount);
        setTranslateX(x*FIELD_SIZE);
        setTranslateY(y*FIELD_SIZE);

        if (bomb) {
            text="x";
        }


        this.setOnMouseClicked(e -> onFieldClick(e));



    }

    /**
     * Checks for each mouseclick if the game is:
     * 1, Won, via checkWin,
     * 2, If a flag has been set,
     * 3, If a field has been uncovered.
     * @param e
     */
    public void onFieldClick(MouseEvent e) {

        if (e.getButton() == MouseButton.PRIMARY) {
            openField();
        }

        if (e.getButton() == MouseButton.SECONDARY && this.flagged == false) {
            fieldNode.setFill(Color.RED);
            bombCount.setVisible(false);
            this.flagged = true;
        } else if (e.getButton() == MouseButton.SECONDARY && this.flagged == true) {
            fieldNode.setFill(Color.rgb(224, 186, 173));
            if(bombCount.getText().equals("X") || oncebomb == true){
                fieldNode.setFill(Color.LIGHTGRAY);
                oncebomb = true;
                bombCount.setVisible(false);
                bombCount.setText("");
            }
            bombCount.setVisible(true);
            this.flagged = false;
        }

    }

    /**
     * Sets styles for the fields.
     */
    private void setFieldStyles() {
        fieldNode = new Rectangle(FIELD_SIZE, FIELD_SIZE);
        fieldNode.setFill(Color.DARKGRAY);
        fieldNode.setStroke(Color.RED);
        fieldNode.setVisible(true);
    }

    /**
     * Secondary function for the main Mouseevent function.
     * @param event
     */
    private void open(MouseEvent event) {
        openField();
    }

    /**
     * Opens Fields via Recursion.
     * Closes the game if a bomb is hit.
     */
    public void openField() {
        if (this.visited)
            return;
        this.visited = true;
        bombCount.setVisible(true);
        this.fieldNode.setFill(Color.rgb(224, 186, 173));

        if (this.bombCount.getText().equals("")) {
             for (Field f : MinesweeperGame.getNeighbours(this)) {
                f.openField();
             }
        }
        if (MinesweeperGame.checkWin()) {
            MinesweeperGame.setWinner(true);
        }
        if (bombCount.getText().isEmpty()) {
            MinesweeperGame.getNeighbours(this).forEach(Field::openField);
        } else if (bombCount.getText().equals("X")) {
            fieldNode.setFill(Color.RED);
            MinesweeperGame.setWinner(false);
        }
    }

    /**
     * Getters and Setters.
     * @return
     */
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    /**
     * Sets the bomb count.
     * @param bombCount
     */
    public void setBombCount(String bombCount) {
        this.bombCount.setText(bombCount);
    }

    public Node getStyleableNode() {
        return super.getStyleableNode();
    }

    /**
     * General toString-method.
     * @return
     */
    @Override
    public String toString() {
        return "Field: " + "x=" + x + ", y=" + y + ", bomb=" + bomb;
    }
}
